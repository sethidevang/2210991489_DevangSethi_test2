//
//  MealTableViewCell.swift
//  2210991489_Test2
//
//  Created by Devang Sethi on 23/11/24.
//

import UIKit

class MealTableViewCell: UITableViewCell {

    @IBOutlet weak var photo: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var prepTime: UILabel!
    
    @IBOutlet weak var calorie: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func updateUI(meal : Meal){
        name.text = meal.recipeName
        photo.image = UIImage(systemName: meal.thumbnailImage ?? "person")
        calorie.text = "Cal: \(meal.CalorieCount ?? "")"
        prepTime.text = "Time: \(meal.preparetionTime ?? "")"
    }

}
