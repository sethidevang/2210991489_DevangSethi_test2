//
//  Meal.swift
//  2210991489_Test2
//
//  Created by Devang Sethi on 23/11/24.
//

import Foundation

enum MealType : String, CaseIterable {
    case breakfast
    case lunch
    case dinner
    case snacks
}

struct Meal {
    var recipeName : String?
    var CalorieCount : String?
    var preparetionTime : String?
    var preparetionInstruction : String?
    var thumbnailImage : String?
    var ingredients : String?
    var Category : String?
    var mealType : String?
}

typealias mealDataType = [MealType : [Meal]]
