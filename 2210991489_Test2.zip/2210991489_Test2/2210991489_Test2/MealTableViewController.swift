//
//  MealTableViewController.swift
//  2210991489_Test2
//
//  Created by Devang Sethi on 23/11/24.
//

import UIKit

class MealTableViewController: UITableViewController {

//    var meal : [Meal] = [Meal(recipeName: <#T##String#>, CalorieCount: <#T##String#>, preparetionTime: <#T##String#>, thumbnailImage: <#T##String#>)]
    var meal : mealDataType = [.breakfast : [Meal(recipeName: "b1", CalorieCount: "10", preparetionTime: "10", thumbnailImage: "person")],
                               .lunch : [Meal(recipeName: "l1", CalorieCount: "10", preparetionTime: "10", thumbnailImage: "person", ingredients: "ing", Category: "cat")],
                               .dinner : [Meal(recipeName: "d1", CalorieCount: "10", preparetionTime: "10", thumbnailImage: "person",ingredients: "ing", Category: "cat")],
                               .snacks : [Meal(recipeName: "s1", CalorieCount: "10", preparetionTime: "10", thumbnailImage: "person",ingredients: "ing", Category: "cat")]]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
         self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return meal.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let mealType = MealType.allCases[section]
        return meal[mealType]?.count ?? 0
    }


    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return MealType.allCases[section].rawValue
    }
    
    

    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as? MealTableViewCell else {return UITableViewCell()}
        
        let mealType = MealType.allCases[indexPath.section]
            if let meals = meal[mealType] {
                let meal = meals[indexPath.row]
                cell.updateUI(meal: meal)
            }
            return cell
    }
    

    @IBSegueAction func detailView(_ coder: NSCoder, sender: Any?) -> DetailTableViewController? {
        guard let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) else {return nil}
        let mealType = MealType.allCases[indexPath.section]
            guard let selectedMeal = meal[mealType]?[indexPath.row] else { return nil }
        return DetailTableViewController(meal: selectedMeal, coder: coder)
    }
//    @IBSegueAction func addActionSegway(_ coder: NSCoder, sender: Any?) -> AddEditTableViewController? {
//        
//        return AddEditTableViewController(data: nil, coder: coder)
//    }
    
    @IBAction func unwindToMain(_ unwindSegue: UIStoryboardSegue) {
        guard let source = unwindSegue.source as? AddEditTableViewController,
              let data = source.data else {return}
//        let mealType =
//                meal[mealType]?.append(data)
//                let newIndexPath = IndexPath(row: meal[mealType]!.count - 1, section: MealType.allCases.firstIndex(of: mealType)!)
//                tableView.insertRows(at: [newIndexPath], with: .automatic)
//        }
//        let sourceViewController = unwindSegue.source
        
        // Use data from the view controller which initiated the unwind segue
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            let mealType = MealType.allCases[indexPath.section]
                    
                    // Safely unwrap the meals array for the corresponding meal type
                    if var meals = meal[mealType] {
                        // Remove the meal at the specified index
                        meals.remove(at: indexPath.row)
                        
                        // Update the dictionary with the modified array
                        meal[mealType] = meals
                        
                        // Delete the row from the table view
                        tableView.deleteRows(at: [indexPath], with: .fade)
                    }
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
